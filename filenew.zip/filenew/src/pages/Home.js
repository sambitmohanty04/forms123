import React from 'react';
import Form1 from './Form1';
import BirthdayList from './BirthdayList';
import Tours from './Tours';

const Home = () => {
  return (
    <>
      <div className='container'>
        <h3>Hello My Friend</h3>
        {/* <Form1 /> */}
        <div className='row'>
          <div className='col-md-4'>
            <BirthdayList />
          </div>
          <div className='col-md-4'>
            <Tours />
          </div>
          <div className='col-md-4'>
            <BirthdayList />
          </div>
        </div>
        
      </div>
    </>
  )
}

export default Home
