import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <>
      <div className='header'>
      <nav className="navbar navbar-expand-lg navbar-light bg-dark">
        <a className="navbar-brand" href="#">
            Navbar
        </a>
        <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
            <Link to='/'>Home</Link>
            </li>
            <li className="nav-item px-3">
            <Link to='/register'>Register</Link>
            </li>
            <li className="nav-item px-3">
            <Link to='/login'>Login</Link>
            </li>
            <li className="nav-item px-3">
            <Link to='/todo'>
                Todo
                </Link>
            </li>
            <li className="nav-item px-3">
            <Link to='/contactList'>
                Contact List
                </Link>
            </li>
            <li className="nav-item px-3">
                <Link to='/shoppingCart'>Cart</Link>
              </li>
              <li className="nav-item px-3">
                <Link to='/registrationForm'>RegistrationForm</Link>
              </li>
              <li className="nav-item px-3">
                <Link to='/loginForm'>LoginForm</Link>
              </li>

            </ul>
            
        </div>
        </nav>
      </div>
    </>
  )
}

export default Header
