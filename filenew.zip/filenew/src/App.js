import './App.css';
import {
  BrowserRouter as Router,
  Route,
  Routes
} from "react-router-dom";




import Header from './component/Header';
import Home from './pages/Home';
import Register from './component/Register';
import Login from './component/Login';


function App() {
  return (
    <>
    <h2>react bootstrap</h2>
    
    <Router>
      
      
      <Header />  
      <Routes>
      <Route exact path='/' element={<Home />} />
        <Route exact path='/register' element={<Register />} />
        <Route exact path='/login' element={<Login />} />
      </Routes>
    </Router>
    </>
  );
}

export default App;
